from setuptools import setup

setup(name='prob_tools',
      version='1.2',
      description='Gaussian distributions',
      packages=['prob_tools'],
      zip_safe=False)
